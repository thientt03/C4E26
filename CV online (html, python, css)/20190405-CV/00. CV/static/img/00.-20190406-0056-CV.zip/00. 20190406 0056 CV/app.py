from flask import Flask,render_template, redirect, request,session,redirect
import user,dbuser,db
app = Flask(__name__)
app.config["SECRET_KEY"]="ailanguoiay"

@app.route('/home')
def home():
    return render_template("home.html")

@app.route('/interface')
def interface():
    return render_template("interface.html")

@app.route("/login", methods = ["GET","POST"])
def login():
    if request.method == "GET":
        return render_template("login2.html")
    elif request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if user.find_by_username(username) == None:
            return render_template("interface.html")
        elif user.find_by_password(password) == None:
            return render_template("interface.html")
        else:
            session["token"]=username
            return redirect('/add')
@app.route("/signin",methods = ["GET","POST"])
def signin():
    if request.method=="GET":
        return render_template("signin.html")
    elif request.method=="POST":
        form=request.form
        u=form["username"]
        p=form["password"]
        if user.find_by_username(str(u))==None:

            new_user={
                "username": str(u),
                "password": str(p),
            }
            db.user_collection.insert_one(new_user)
            return "đã đăng kí thành công"
        elif user.find_by_username(str(u))!=None:
            return "đã có,mời nhập lại"
        if str(u)==None:
            return "kkk"
        
        
        




@app.route("/add", methods = ["GET","POST"])
def add():
    if request.method == "GET":
        return render_template("interfaceform.html")
    elif request.method == "POST":

        form = request.form
        img_file = form['base64']
        cvtitle = form["cvtitle"]
        fullname = form["fullname"]
        nominee = form["nominee"]
        dateofbirth = form["dateofbirth"]
        sex = form["sex"]
        numberphone = form["numberphone"]
        addressemail = form["addressemail"]
        address = form["address"]
        website = form["website"]
        awareness = form["awareness"]
        hobby = form["hobby"]
        skillname = form["skillname"]
        schoolname = form["schoolname"]
        startschool = form["startschool"]
        endschool = form["endschool"]
        majors = form["majors"]
        describe = form["describe"]
        companyname = form["companyname"]
        startcompany = form["startcompany"]
        endcompany = form["endcompany"]
        locationcompany = form["locationcompany"]
        jobdescription = form["jobdescription"]
        prize = form["prize"]
        timeprize = form["timeprize"]
        softskill = form["softskill"]
        namecertificate = form["namecertificate"]
        typecertificate = form["typecertificate"]
        diffirent = form["diffirent"]
        dbuser.infuser(img_file,cvtitle,fullname,nominee,dateofbirth,sex,numberphone,addressemail,address,website,awareness,hobby,skillname,schoolname,startschool,endschool,majors,describe,companyname,startcompany,endcompany,locationcompany,jobdescription,prize,timeprize,softskill,namecertificate,typecertificate,diffirent)
        image = dbuser.search_image(img_file)
        # return render_template("interfaceout.html")
        return render_template("interfaceout.html",img_file = image,cvtitle = cvtitle, fullname = fullname, nominee = nominee, dateofbirth = dateofbirth)
# def screen():
#   return render_template("interface.html")
    

if __name__ == '__main__':
  app.run(debug=True)